import React, { useEffect } from 'react';
import { Toaster } from 'react-hot-toast';
import Header from './components/Header';
import Footer from './components/Footer';
import NetworkSelector from './components/NetworkSelector';
import GasSettings from './components/GasSettings';
import MintConfigForm from './components/MintConfigForm';
import ProjectManager from './components/ProjectManager';
import CountdownTimer from './components/CountdownTimer';
import TransactionList from './components/TransactionList';
import MintButton from './components/MintButton';

function App() {
  return (
    <div className="min-h-screen bg-dark-900 text-white">
      <Toaster
        position="top-right"
        toastOptions={{
          style: {
            background: '#1e293b',
            color: '#fff',
            borderRadius: '8px',
            border: '1px solid #334155',
          },
          success: {
            iconTheme: {
              primary: '#22c55e',
              secondary: '#fff',
            },
          },
          error: {
            iconTheme: {
              primary: '#ef4444',
              secondary: '#fff',
            },
          },
        }}
      />
      
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <NetworkSelector />
            </div>
            
            <MintConfigForm />
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <GasSettings />
              <div className="space-y-6">
                <CountdownTimer />
                <MintButton />
              </div>
            </div>
            
            <TransactionList />
          </div>
          
          <div className="space-y-6">
            <ProjectManager />
            
            <div className="bg-dark-800 rounded-lg p-4 border border-dark-700">
              <h2 className="text-lg font-semibold text-white mb-3">Instructions</h2>
              <ol className="list-decimal ml-5 space-y-2 text-gray-300 text-sm">
                <li>Connect your wallet and select the correct network</li>
                <li>Enter the NFT contract address and configuration</li>
                <li>Set the mint start time (use "Now" for immediate minting)</li>
                <li>Adjust gas settings for optimal transaction success</li>
                <li>Click "Mint NFT" when the drop goes live</li>
                <li>Save your configuration for future use</li>
              </ol>
              
              <div className="mt-4 p-3 bg-dark-900 rounded border border-warning-800 text-warning-500 text-xs">
                <p className="font-semibold mb-1">⚠️ Important:</p>
                <ul className="list-disc ml-4 space-y-1">
                  <li>Always verify contract addresses before minting</li>
                  <li>Test with small transactions first</li>
                  <li>Be aware of blockchain network fees</li>
                  <li>This tool is provided as-is with no guarantees</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}

export default App;