export interface NetworkConfig {
  chainId: number;
  name: string;
  rpc: string;
  symbol: string;
  blockExplorer: string;
}

export interface WalletInfo {
  address: string;
  balance: string;
  network: NetworkConfig;
  provider: any;
  signer: any;
  connected: boolean;
}

export interface GasSettings {
  maxFeePerGas: string;
  maxPriorityFeePerGas: string;
  gasLimit: string;
}

export interface MintConfig {
  contractAddress: string;
  mintFunction: string;
  mintPrice: string;
  mintQuantity: number;
  startTime: number; // Unix timestamp
  whitelistRequired: boolean;
  merkleProof?: string[];
  arguments?: any[];
}

export interface SavedProject {
  id: string;
  name: string;
  mintConfig: MintConfig;
  gasSettings: GasSettings;
  network: NetworkConfig;
}

export interface TransactionStatus {
  hash: string;
  status: 'pending' | 'confirmed' | 'failed';
  confirmations: number;
  error?: string;
  timestamp: number;
}

export enum ConnectionStatus {
  DISCONNECTED = 'disconnected',
  CONNECTING = 'connecting',
  CONNECTED = 'connected',
  ERROR = 'error',
}