import { NetworkConfig } from '../types';

export const NETWORKS: Record<number, NetworkConfig> = {
  1: {
    chainId: 1,
    name: 'Ethereum',
    rpc: 'https://mainnet.infura.io/v3/',
    symbol: 'ETH',
    blockExplorer: 'https://etherscan.io',
  },
  137: {
    chainId: 137,
    name: 'Polygon',
    rpc: 'https://polygon-rpc.com',
    symbol: 'MATIC',
    blockExplorer: 'https://polygonscan.com',
  },
  42161: {
    chainId: 42161,
    name: 'Arbitrum',
    rpc: 'https://arb1.arbitrum.io/rpc',
    symbol: 'ETH',
    blockExplorer: 'https://arbiscan.io',
  },
  10: {
    chainId: 10,
    name: 'Optimism',
    rpc: 'https://mainnet.optimism.io',
    symbol: 'ETH',
    blockExplorer: 'https://optimistic.etherscan.io',
  },
  56: {
    chainId: 56,
    name: 'BNB Smart Chain',
    rpc: 'https://bsc-dataseed.binance.org',
    symbol: 'BNB',
    blockExplorer: 'https://bscscan.com',
  },
  43114: {
    chainId: 43114,
    name: 'Avalanche',
    rpc: 'https://api.avax.network/ext/bc/C/rpc',
    symbol: 'AVAX',
    blockExplorer: 'https://snowtrace.io',
  },
};

export const DEFAULT_NETWORK = NETWORKS[1];