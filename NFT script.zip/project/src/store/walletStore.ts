import { create } from 'zustand';
import { ConnectionStatus, NetworkConfig, WalletInfo } from '../types';
import { DEFAULT_NETWORK } from '../constants/networks';
import { connectWallet, switchNetwork } from '../utils/web3';

interface WalletState {
  wallet: WalletInfo | null;
  status: ConnectionStatus;
  error: string | null;
  connectWallet: () => Promise<void>;
  disconnectWallet: () => void;
  switchNetwork: (chainId: number) => Promise<void>;
}

const defaultWalletInfo: WalletInfo = {
  address: '',
  balance: '0',
  network: DEFAULT_NETWORK,
  provider: null,
  signer: null,
  connected: false,
};

export const useWalletStore = create<WalletState>((set, get) => ({
  wallet: null,
  status: ConnectionStatus.DISCONNECTED,
  error: null,
  
  connectWallet: async () => {
    try {
      set({ status: ConnectionStatus.CONNECTING, error: null });
      const walletInfo = await connectWallet();
      set({ wallet: walletInfo, status: ConnectionStatus.CONNECTED });
    } catch (error: any) {
      set({ 
        status: ConnectionStatus.ERROR, 
        error: error.message || 'Failed to connect wallet' 
      });
    }
  },
  
  disconnectWallet: () => {
    set({ 
      wallet: null, 
      status: ConnectionStatus.DISCONNECTED, 
      error: null 
    });
  },
  
  switchNetwork: async (chainId: number) => {
    try {
      set({ status: ConnectionStatus.CONNECTING, error: null });
      await switchNetwork(chainId);
      
      // After switching, we need to reconnect to get updated wallet info
      const walletInfo = await connectWallet();
      set({ wallet: walletInfo, status: ConnectionStatus.CONNECTED });
    } catch (error: any) {
      set({ 
        status: ConnectionStatus.ERROR, 
        error: error.message || 'Failed to switch network' 
      });
    }
  },
}));