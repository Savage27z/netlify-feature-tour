import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { GasSettings, MintConfig, SavedProject, TransactionStatus } from '../types';
import { checkTransactionStatus, estimateGas, getCurrentGasPrice, mintNFT } from '../utils/web3';
import { ethers } from 'ethers';

interface MintState {
  // Current settings
  currentProject: SavedProject | null;
  gasSettings: GasSettings;
  mintConfig: MintConfig;
  
  // Saved projects
  savedProjects: SavedProject[];
  
  // Transaction tracking
  transactions: TransactionStatus[];
  
  // Actions
  updateGasSettings: (settings: Partial<GasSettings>) => void;
  updateMintConfig: (config: Partial<MintConfig>) => void;
  saveProject: (name: string) => void;
  loadProject: (id: string) => void;
  deleteProject: (id: string) => void;
  
  startMint: (signer: ethers.Signer) => Promise<string>;
  updateTransactionStatus: (provider: ethers.providers.Provider, txHash: string) => Promise<void>;
  
  loadGasPrices: (provider: ethers.providers.Provider) => Promise<void>;
  estimateGasLimit: (provider: ethers.providers.Provider, contractAddress: string) => Promise<void>;
}

const DEFAULT_GAS_SETTINGS: GasSettings = {
  maxFeePerGas: '50',
  maxPriorityFeePerGas: '1.5',
  gasLimit: '250000',
};

const DEFAULT_MINT_CONFIG: MintConfig = {
  contractAddress: '',
  mintFunction: 'mint(uint256)',
  mintPrice: '0.08',
  mintQuantity: 1,
  startTime: 0,
  whitelistRequired: false,
  arguments: [1], // Default to minting 1 NFT
};

export const useMintStore = create<MintState>()(
  persist(
    (set, get) => ({
      currentProject: null,
      gasSettings: DEFAULT_GAS_SETTINGS,
      mintConfig: DEFAULT_MINT_CONFIG,
      savedProjects: [],
      transactions: [],
      
      updateGasSettings: (settings) => {
        set((state) => ({
          gasSettings: {
            ...state.gasSettings,
            ...settings,
          },
        }));
      },
      
      updateMintConfig: (config) => {
        set((state) => ({
          mintConfig: {
            ...state.mintConfig,
            ...config,
          },
        }));
      },
      
      saveProject: (name) => {
        const { mintConfig, gasSettings } = get();
        const id = Date.now().toString();
        
        const newProject: SavedProject = {
          id,
          name,
          mintConfig,
          gasSettings,
          network: { chainId: 1, name: 'Ethereum', rpc: '', symbol: 'ETH', blockExplorer: '' },
        };
        
        set((state) => ({
          savedProjects: [...state.savedProjects, newProject],
          currentProject: newProject,
        }));
      },
      
      loadProject: (id) => {
        const { savedProjects } = get();
        const project = savedProjects.find((p) => p.id === id);
        
        if (project) {
          set({
            currentProject: project,
            mintConfig: project.mintConfig,
            gasSettings: project.gasSettings,
          });
        }
      },
      
      deleteProject: (id) => {
        set((state) => ({
          savedProjects: state.savedProjects.filter((p) => p.id !== id),
          currentProject: state.currentProject?.id === id ? null : state.currentProject,
        }));
      },
      
      startMint: async (signer) => {
        const { mintConfig, gasSettings } = get();
        const txHash = await mintNFT(signer, mintConfig, gasSettings);
        
        const newTx: TransactionStatus = {
          hash: txHash,
          status: 'pending',
          confirmations: 0,
          timestamp: Date.now(),
        };
        
        set((state) => ({
          transactions: [newTx, ...state.transactions],
        }));
        
        return txHash;
      },
      
      updateTransactionStatus: async (provider, txHash) => {
        const status = await checkTransactionStatus(provider, txHash);
        
        set((state) => ({
          transactions: state.transactions.map((tx) =>
            tx.hash === txHash ? status : tx
          ),
        }));
      },
      
      loadGasPrices: async (provider) => {
        const { maxFeePerGas, maxPriorityFeePerGas } = await getCurrentGasPrice(provider);
        
        set((state) => ({
          gasSettings: {
            ...state.gasSettings,
            maxFeePerGas,
            maxPriorityFeePerGas,
          },
        }));
      },
      
      estimateGasLimit: async (provider, contractAddress) => {
        if (!contractAddress) return;
        
        const gasLimit = await estimateGas(provider, contractAddress);
        
        set((state) => ({
          gasSettings: {
            ...state.gasSettings,
            gasLimit,
          },
        }));
      },
    }),
    {
      name: 'nft-minting-storage',
      partialize: (state) => ({
        savedProjects: state.savedProjects,
        transactions: state.transactions.slice(0, 10), // Only store the 10 most recent transactions
      }),
    }
  )
);