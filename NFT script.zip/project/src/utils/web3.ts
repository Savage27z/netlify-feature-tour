import { ethers } from 'ethers';
import { GasSettings, MintConfig, TransactionStatus } from '../types';

export const connectWallet = async () => {
  if (!window.ethereum) {
    throw new Error('MetaMask is not installed');
  }

  try {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    await provider.send('eth_requestAccounts', []);
    const signer = provider.getSigner();
    const address = await signer.getAddress();
    const balance = ethers.utils.formatEther(await provider.getBalance(address));
    const network = await provider.getNetwork();

    return {
      address,
      balance,
      network,
      provider,
      signer,
      connected: true,
    };
  } catch (error) {
    console.error('Error connecting wallet:', error);
    throw error;
  }
};

export const switchNetwork = async (chainId: number) => {
  if (!window.ethereum) {
    throw new Error('MetaMask is not installed');
  }

  try {
    await window.ethereum.request({
      method: 'wallet_switchEthereumChain',
      params: [{ chainId: `0x${chainId.toString(16)}` }],
    });
    return true;
  } catch (error: any) {
    // If the chain hasn't been added to MetaMask
    if (error.code === 4902) {
      // You could add the chain here
      throw new Error('This network is not available in your MetaMask, please add it manually');
    }
    console.error('Error switching network:', error);
    throw error;
  }
};

export const mintNFT = async (
  signer: ethers.Signer,
  mintConfig: MintConfig,
  gasSettings: GasSettings
): Promise<string> => {
  try {
    const abi = ['function ' + mintConfig.mintFunction];
    const contract = new ethers.Contract(mintConfig.contractAddress, abi, signer);
    
    // Convert string gas params to BigNumber
    const maxFeePerGas = ethers.utils.parseUnits(gasSettings.maxFeePerGas, 'gwei');
    const maxPriorityFeePerGas = ethers.utils.parseUnits(gasSettings.maxPriorityFeePerGas, 'gwei');
    const gasLimit = ethers.BigNumber.from(gasSettings.gasLimit);
    
    // Construct arguments for the mint function
    const args = mintConfig.arguments || [];
    
    // Determine the value to send (mint price)
    const value = ethers.utils.parseEther(mintConfig.mintPrice);
    
    // Create transaction options
    const txOptions = {
      value,
      maxFeePerGas,
      maxPriorityFeePerGas,
      gasLimit,
    };
    
    // Call the mint function with the appropriate arguments
    const tx = await contract[mintConfig.mintFunction](...args, txOptions);
    
    return tx.hash;
  } catch (error) {
    console.error('Error minting NFT:', error);
    throw error;
  }
};

export const checkTransactionStatus = async (
  provider: ethers.providers.Provider,
  txHash: string
): Promise<TransactionStatus> => {
  try {
    const tx = await provider.getTransaction(txHash);
    
    if (!tx) {
      return {
        hash: txHash,
        status: 'pending',
        confirmations: 0,
        timestamp: Date.now(),
      };
    }
    
    if (tx.blockNumber) {
      const receipt = await provider.getTransactionReceipt(txHash);
      
      // Transaction confirmed but failed
      if (receipt && receipt.status === 0) {
        return {
          hash: txHash,
          status: 'failed',
          confirmations: tx.confirmations,
          error: 'Transaction failed',
          timestamp: Date.now(),
        };
      }
      
      // Transaction confirmed and successful
      return {
        hash: txHash,
        status: 'confirmed',
        confirmations: tx.confirmations,
        timestamp: Date.now(),
      };
    }
    
    // Transaction still pending
    return {
      hash: txHash,
      status: 'pending',
      confirmations: 0,
      timestamp: Date.now(),
    };
  } catch (error) {
    console.error('Error checking transaction status:', error);
    return {
      hash: txHash,
      status: 'failed',
      confirmations: 0,
      error: 'Error checking status',
      timestamp: Date.now(),
    };
  }
};

export const estimateGas = async (
  provider: ethers.providers.Provider,
  to: string,
  data?: string
): Promise<string> => {
  try {
    const gasLimit = await provider.estimateGas({
      to,
      data,
    });
    
    // Add a buffer to the estimated gas limit for safety
    const gasLimitWithBuffer = gasLimit.mul(ethers.BigNumber.from(120)).div(ethers.BigNumber.from(100));
    
    return gasLimitWithBuffer.toString();
  } catch (error) {
    console.error('Error estimating gas:', error);
    return '250000'; // Default gas limit as fallback
  }
};

export const getCurrentGasPrice = async (
  provider: ethers.providers.Provider
): Promise<{ maxFeePerGas: string; maxPriorityFeePerGas: string }> => {
  try {
    const feeData = await provider.getFeeData();
    
    let maxFeePerGas = '50';
    let maxPriorityFeePerGas = '1.5';
    
    if (feeData.maxFeePerGas) {
      maxFeePerGas = ethers.utils.formatUnits(feeData.maxFeePerGas, 'gwei');
    }
    
    if (feeData.maxPriorityFeePerGas) {
      maxPriorityFeePerGas = ethers.utils.formatUnits(feeData.maxPriorityFeePerGas, 'gwei');
    }
    
    return {
      maxFeePerGas,
      maxPriorityFeePerGas,
    };
  } catch (error) {
    console.error('Error getting gas price:', error);
    return {
      maxFeePerGas: '50',
      maxPriorityFeePerGas: '1.5',
    };
  }
};

// Time synchronization for drop timing
export const getServerTime = async (): Promise<number> => {
  try {
    const response = await fetch('https://worldtimeapi.org/api/ip');
    const data = await response.json();
    return Math.floor(new Date(data.datetime).getTime() / 1000);
  } catch (error) {
    console.error('Error getting server time:', error);
    return Math.floor(Date.now() / 1000);
  }
};