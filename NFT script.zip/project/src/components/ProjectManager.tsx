import React, { useState } from 'react';
import { Save, FolderOpen, Trash2 } from 'lucide-react';
import { useMintStore } from '../store/mintStore';

const ProjectManager: React.FC = () => {
  const { savedProjects, currentProject, saveProject, loadProject, deleteProject } = useMintStore();
  const [projectName, setProjectName] = useState('');
  const [showSaveForm, setShowSaveForm] = useState(false);
  
  const handleSave = () => {
    if (projectName.trim()) {
      saveProject(projectName);
      setProjectName('');
      setShowSaveForm(false);
    }
  };
  
  return (
    <div className="bg-dark-800 rounded-lg p-4 border border-dark-700">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold text-white flex items-center gap-2">
          <FolderOpen size={18} className="text-primary-400" />
          Projects
        </h2>
        <button
          onClick={() => setShowSaveForm(!showSaveForm)}
          className="text-sm px-3 py-1 bg-primary-600 hover:bg-primary-700 text-white rounded transition-colors flex items-center gap-1"
        >
          <Save size={14} />
          Save Configuration
        </button>
      </div>
      
      {showSaveForm && (
        <div className="mb-4 flex gap-2">
          <input
            type="text"
            value={projectName}
            onChange={(e) => setProjectName(e.target.value)}
            placeholder="Project name"
            className="flex-1 bg-dark-900 border border-dark-700 text-white rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-primary-500"
          />
          <button
            onClick={handleSave}
            disabled={!projectName.trim()}
            className="bg-primary-600 hover:bg-primary-700 disabled:opacity-50 disabled:cursor-not-allowed text-white px-3 py-1 rounded transition-colors"
          >
            Save
          </button>
        </div>
      )}
      
      {savedProjects.length === 0 ? (
        <p className="text-gray-400 text-sm py-2">No saved projects</p>
      ) : (
        <ul className="space-y-2 max-h-40 overflow-y-auto">
          {savedProjects.map((project) => (
            <li
              key={project.id}
              className={`flex justify-between items-center p-2 rounded-md ${
                currentProject?.id === project.id ? 'bg-primary-900 bg-opacity-30' : 'bg-dark-700'
              }`}
            >
              <button
                onClick={() => loadProject(project.id)}
                className="text-left w-full flex-1 text-white hover:text-primary-300 transition-colors"
              >
                {project.name}
              </button>
              <button
                onClick={() => deleteProject(project.id)}
                className="text-gray-400 hover:text-error-500 transition-colors"
              >
                <Trash2 size={16} />
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default ProjectManager;