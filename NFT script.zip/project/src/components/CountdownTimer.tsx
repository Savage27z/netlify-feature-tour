import React, { useState, useEffect } from 'react';
import { Clock, AlertTriangle } from 'lucide-react';
import { useMintStore } from '../store/mintStore';
import { getServerTime } from '../utils/web3';

interface TimeLeft {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
}

const CountdownTimer: React.FC = () => {
  const { mintConfig } = useMintStore();
  const [timeLeft, setTimeLeft] = useState<TimeLeft>({ days: 0, hours: 0, minutes: 0, seconds: 0 });
  const [currentTime, setCurrentTime] = useState<number>(Math.floor(Date.now() / 1000));
  const [timeSync, setTimeSync] = useState<'synced' | 'local' | 'syncing'>('local');
  
  useEffect(() => {
    const syncServerTime = async () => {
      try {
        setTimeSync('syncing');
        const serverTime = await getServerTime();
        setCurrentTime(serverTime);
        setTimeSync('synced');
      } catch (error) {
        console.error('Failed to sync server time:', error);
        setTimeSync('local');
      }
    };
    
    syncServerTime();
    
    // Set up interval to keep local time updated
    const intervalId = setInterval(() => {
      setCurrentTime((prev) => prev + 1);
    }, 1000);
    
    // Sync with server every minute
    const syncIntervalId = setInterval(() => {
      syncServerTime();
    }, 60000);
    
    return () => {
      clearInterval(intervalId);
      clearInterval(syncIntervalId);
    };
  }, []);
  
  useEffect(() => {
    if (!mintConfig.startTime) return;
    
    const calculateTimeLeft = () => {
      const difference = mintConfig.startTime - currentTime;
      
      if (difference <= 0) {
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 });
        return;
      }
      
      setTimeLeft({
        days: Math.floor(difference / (60 * 60 * 24)),
        hours: Math.floor((difference % (60 * 60 * 24)) / (60 * 60)),
        minutes: Math.floor((difference % (60 * 60)) / 60),
        seconds: difference % 60,
      });
    };
    
    calculateTimeLeft();
  }, [currentTime, mintConfig.startTime]);
  
  const isMintLive = mintConfig.startTime && currentTime >= mintConfig.startTime;
  
  return (
    <div className="bg-dark-800 rounded-lg p-4 border border-dark-700">
      <div className="flex justify-between items-center mb-2">
        <h2 className="text-lg font-semibold text-white flex items-center gap-2">
          <Clock size={18} className="text-primary-400" />
          Drop Countdown
        </h2>
        <div className="flex items-center gap-1 text-xs">
          <span
            className={`inline-block w-2 h-2 rounded-full ${
              timeSync === 'synced'
                ? 'bg-success-500'
                : timeSync === 'syncing'
                ? 'bg-warning-500'
                : 'bg-error-500'
            }`}
          ></span>
          <span className="text-gray-400">
            {timeSync === 'synced' ? 'Time synced' : timeSync === 'syncing' ? 'Syncing...' : 'Local time'}
          </span>
        </div>
      </div>
      
      {!mintConfig.startTime ? (
        <div className="flex items-center justify-center py-4 text-warning-500 gap-2">
          <AlertTriangle size={16} />
          <span>No start time configured</span>
        </div>
      ) : isMintLive ? (
        <div className="text-center py-4">
          <div className="text-2xl font-bold text-success-500 animate-pulse">MINT IS LIVE</div>
          <p className="text-white text-sm mt-2">
            {new Date(mintConfig.startTime * 1000).toLocaleString()}
          </p>
        </div>
      ) : (
        <div className="py-2">
          <div className="grid grid-cols-4 gap-2 mb-2">
            <div className="bg-dark-900 rounded-md p-2 text-center">
              <div className="text-2xl font-bold text-primary-400">{timeLeft.days}</div>
              <div className="text-xs text-gray-400">Days</div>
            </div>
            <div className="bg-dark-900 rounded-md p-2 text-center">
              <div className="text-2xl font-bold text-primary-400">{timeLeft.hours}</div>
              <div className="text-xs text-gray-400">Hours</div>
            </div>
            <div className="bg-dark-900 rounded-md p-2 text-center">
              <div className="text-2xl font-bold text-primary-400">{timeLeft.minutes}</div>
              <div className="text-xs text-gray-400">Mins</div>
            </div>
            <div className="bg-dark-900 rounded-md p-2 text-center">
              <div className="text-2xl font-bold text-primary-400">{timeLeft.seconds}</div>
              <div className="text-xs text-gray-400">Secs</div>
            </div>
          </div>
          <p className="text-center text-sm text-gray-400">
            Drop time: {new Date(mintConfig.startTime * 1000).toLocaleString()}
          </p>
        </div>
      )}
    </div>
  );
};

export default CountdownTimer;