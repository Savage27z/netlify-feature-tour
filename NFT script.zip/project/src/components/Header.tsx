import React from 'react';
import { Zap } from 'lucide-react';
import WalletConnector from './WalletConnector';

const Header: React.FC = () => {
  return (
    <header className="py-4 border-b border-dark-700">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Zap size={24} className="text-primary-500" />
            <h1 className="text-xl font-bold text-white">NFT Minting Bot</h1>
          </div>
          
          <WalletConnector />
        </div>
      </div>
    </header>
  );
};

export default Header;