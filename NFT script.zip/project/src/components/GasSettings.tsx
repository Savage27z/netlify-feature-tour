import React from 'react';
import { Sliders, Info } from 'lucide-react';
import { useMintStore } from '../store/mintStore';
import { useWalletStore } from '../store/walletStore';

const GasSettings: React.FC = () => {
  const { gasSettings, updateGasSettings, loadGasPrices } = useMintStore();
  const { wallet } = useWalletStore();
  
  const handleRefreshGas = async () => {
    if (wallet?.provider) {
      await loadGasPrices(wallet.provider);
    }
  };
  
  return (
    <div className="bg-dark-800 rounded-lg p-4 border border-dark-700">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold text-white flex items-center gap-2">
          <Sliders size={18} className="text-primary-400" />
          Gas Settings
        </h2>
        <button
          onClick={handleRefreshGas}
          disabled={!wallet?.provider}
          className="text-xs px-2 py-1 bg-dark-700 hover:bg-dark-600 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded transition-colors"
        >
          Refresh Gas Prices
        </button>
      </div>
      
      <div className="space-y-4">
        <div>
          <label className="flex items-center gap-1 text-sm font-medium text-gray-300 mb-1">
            Max Fee (Gwei)
            <div className="group relative">
              <Info size={14} className="text-gray-400 cursor-help" />
              <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-48 p-2 bg-dark-900 text-gray-300 text-xs rounded shadow-lg opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                Maximum amount per unit of gas you're willing to pay in total
              </div>
            </div>
          </label>
          <input
            type="number"
            value={gasSettings.maxFeePerGas}
            onChange={(e) => updateGasSettings({ maxFeePerGas: e.target.value })}
            className="w-full bg-dark-900 border border-dark-700 text-white rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-primary-500"
            min="0"
            step="0.1"
          />
        </div>
        
        <div>
          <label className="flex items-center gap-1 text-sm font-medium text-gray-300 mb-1">
            Priority Fee (Gwei)
            <div className="group relative">
              <Info size={14} className="text-gray-400 cursor-help" />
              <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-48 p-2 bg-dark-900 text-gray-300 text-xs rounded shadow-lg opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                Miner tip to prioritize your transaction
              </div>
            </div>
          </label>
          <input
            type="number"
            value={gasSettings.maxPriorityFeePerGas}
            onChange={(e) => updateGasSettings({ maxPriorityFeePerGas: e.target.value })}
            className="w-full bg-dark-900 border border-dark-700 text-white rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-primary-500"
            min="0"
            step="0.1"
          />
        </div>
        
        <div>
          <label className="flex items-center gap-1 text-sm font-medium text-gray-300 mb-1">
            Gas Limit
            <div className="group relative">
              <Info size={14} className="text-gray-400 cursor-help" />
              <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-48 p-2 bg-dark-900 text-gray-300 text-xs rounded shadow-lg opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                Maximum amount of gas you're willing to use
              </div>
            </div>
          </label>
          <input
            type="number"
            value={gasSettings.gasLimit}
            onChange={(e) => updateGasSettings({ gasLimit: e.target.value })}
            className="w-full bg-dark-900 border border-dark-700 text-white rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-primary-500"
            min="21000"
            step="1000"
          />
        </div>
      </div>
      
      <div className="mt-4 p-3 bg-dark-900 rounded text-xs text-gray-400">
        <p>
          Estimated max gas cost:{' '}
          <span className="text-accent-400 font-semibold">
            {(
              (parseFloat(gasSettings.maxFeePerGas) * parseFloat(gasSettings.gasLimit)) /
              1e9
            ).toFixed(6)}{' '}
            ETH
          </span>
        </p>
      </div>
    </div>
  );
};

export default GasSettings;