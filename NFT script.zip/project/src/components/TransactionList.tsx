import React, { useEffect } from 'react';
import { useMintStore } from '../store/mintStore';
import { useWalletStore } from '../store/walletStore';
import { formatDistanceToNow } from '../utils/format';
import { CheckCircle, XCircle, Clock, ExternalLink } from 'lucide-react';

const TransactionList: React.FC = () => {
  const { transactions, updateTransactionStatus } = useMintStore();
  const { wallet } = useWalletStore();
  
  // Poll for transaction status updates
  useEffect(() => {
    if (!wallet?.provider) return;
    
    const pendingTxs = transactions.filter((tx) => tx.status === 'pending');
    
    if (pendingTxs.length === 0) return;
    
    const intervalId = setInterval(() => {
      pendingTxs.forEach((tx) => {
        updateTransactionStatus(wallet.provider, tx.hash);
      });
    }, 5000);
    
    return () => clearInterval(intervalId);
  }, [transactions, wallet?.provider, updateTransactionStatus]);
  
  // Sort transactions by timestamp (newest first)
  const sortedTransactions = [...transactions].sort((a, b) => b.timestamp - a.timestamp);
  
  if (transactions.length === 0) {
    return null;
  }
  
  const getExplorerUrl = (hash: string) => {
    if (!wallet?.network?.blockExplorer) return '';
    return `${wallet.network.blockExplorer}/tx/${hash}`;
  };
  
  return (
    <div className="bg-dark-800 rounded-lg p-4 border border-dark-700">
      <h2 className="text-lg font-semibold text-white mb-4">Recent Transactions</h2>
      
      <div className="space-y-3 max-h-64 overflow-y-auto">
        {sortedTransactions.map((tx) => (
          <div
            key={tx.hash}
            className="flex items-center justify-between p-3 bg-dark-900 rounded-md border border-dark-700"
          >
            <div className="flex items-center gap-3">
              <div>
                {tx.status === 'confirmed' ? (
                  <CheckCircle className="text-success-500" size={20} />
                ) : tx.status === 'failed' ? (
                  <XCircle className="text-error-500" size={20} />
                ) : (
                  <Clock className="text-warning-500 animate-spin-slow" size={20} />
                )}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-gray-300 font-medium">
                    {tx.status === 'confirmed'
                      ? 'Confirmed'
                      : tx.status === 'failed'
                      ? 'Failed'
                      : 'Pending'}
                  </span>
                  <span className="text-xs text-gray-500">
                    {formatDistanceToNow(tx.timestamp)}
                  </span>
                </div>
                <div className="text-xs text-gray-400 font-mono">
                  {tx.hash.slice(0, 6)}...{tx.hash.slice(-4)}
                </div>
              </div>
            </div>
            
            <a
              href={getExplorerUrl(tx.hash)}
              target="_blank"
              rel="noopener noreferrer"
              className="text-primary-400 hover:text-primary-300 transition-colors"
            >
              <ExternalLink size={16} />
            </a>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TransactionList;