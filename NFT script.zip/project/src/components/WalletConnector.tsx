import React, { useEffect } from 'react';
import { Wallet, AlertCircle, CheckCircle, Loader2 } from 'lucide-react';
import { useWalletStore } from '../store/walletStore';
import { ConnectionStatus } from '../types';
import { truncateAddress } from '../utils/format';

const WalletConnector: React.FC = () => {
  const { wallet, status, error, connectWallet, disconnectWallet } = useWalletStore();
  
  // Attempt to reconnect if we have a connection before
  useEffect(() => {
    if (window.ethereum && status === ConnectionStatus.DISCONNECTED && localStorage.getItem('walletConnected') === 'true') {
      connectWallet();
    }
  }, [connectWallet, status]);
  
  // Save connection status
  useEffect(() => {
    if (status === ConnectionStatus.CONNECTED) {
      localStorage.setItem('walletConnected', 'true');
    } else if (status === ConnectionStatus.DISCONNECTED) {
      localStorage.removeItem('walletConnected');
    }
  }, [status]);
  
  const handleConnect = () => {
    connectWallet();
  };
  
  const handleDisconnect = () => {
    disconnectWallet();
  };
  
  return (
    <div className="flex items-center">
      {status === ConnectionStatus.DISCONNECTED && (
        <button
          onClick={handleConnect}
          className="flex items-center gap-2 bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-lg transition-colors"
        >
          <Wallet size={18} />
          Connect Wallet
        </button>
      )}
      
      {status === ConnectionStatus.CONNECTING && (
        <div className="flex items-center gap-2 bg-dark-800 text-white px-4 py-2 rounded-lg">
          <Loader2 size={18} className="animate-spin" />
          Connecting...
        </div>
      )}
      
      {status === ConnectionStatus.CONNECTED && wallet && (
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-2 bg-dark-800 text-white px-4 py-2 rounded-lg">
            <CheckCircle size={18} className="text-success-500" />
            <span>{truncateAddress(wallet.address)}</span>
            <span className="mx-1">|</span>
            <span className="text-primary-400">{wallet.network.name}</span>
          </div>
          <button
            onClick={handleDisconnect}
            className="bg-dark-700 hover:bg-dark-600 text-white px-3 py-2 rounded-lg transition-colors"
          >
            Disconnect
          </button>
        </div>
      )}
      
      {status === ConnectionStatus.ERROR && (
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-2 bg-error-600 text-white px-4 py-2 rounded-lg">
            <AlertCircle size={18} />
            {error || 'Connection error'}
          </div>
          <button
            onClick={handleConnect}
            className="bg-dark-700 hover:bg-dark-600 text-white px-3 py-2 rounded-lg transition-colors"
          >
            Retry
          </button>
        </div>
      )}
    </div>
  );
};

export default WalletConnector;