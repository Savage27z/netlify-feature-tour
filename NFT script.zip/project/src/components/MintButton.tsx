import React, { useState, useEffect } from 'react';
import { useMintStore } from '../store/mintStore';
import { useWalletStore } from '../store/walletStore';
import { Loader2, AlertTriangle } from 'lucide-react';
import toast from 'react-hot-toast';

const MintButton: React.FC = () => {
  const { mintConfig, gasSettings, startMint } = useMintStore();
  const { wallet, status } = useWalletStore();
  const [isMinting, setIsMinting] = useState(false);
  const [countdown, setCountdown] = useState(0);
  const [currentTime, setCurrentTime] = useState<number>(Math.floor(Date.now() / 1000));
  
  // Update current time
  useEffect(() => {
    const intervalId = setInterval(() => {
      setCurrentTime(Math.floor(Date.now() / 1000));
    }, 1000);
    
    return () => clearInterval(intervalId);
  }, []);
  
  const isReadyToMint =
    wallet?.connected &&
    mintConfig.contractAddress &&
    mintConfig.mintFunction &&
    parseFloat(mintConfig.mintPrice) >= 0 &&
    (mintConfig.startTime ? currentTime >= mintConfig.startTime : true);
  
  const handleMint = async () => {
    if (!wallet?.signer || !isReadyToMint) return;
    
    setIsMinting(true);
    
    try {
      const txHash = await startMint(wallet.signer);
      toast.success('Transaction submitted!');
      
      // Monitor transaction in background
      /*
      const txReceipt = await wallet.provider.waitForTransaction(txHash);
      
      if (txReceipt.status === 1) {
        toast.success('Successfully minted NFT!');
      } else {
        toast.error('Minting failed. Transaction was reverted.');
      }
      */
    } catch (error: any) {
      console.error('Mint error:', error);
      toast.error(error.message || 'Failed to mint');
    } finally {
      setIsMinting(false);
    }
  };
  
  const getButtonState = () => {
    if (!wallet?.connected) {
      return {
        disabled: true,
        text: 'Connect Wallet First',
        icon: <AlertTriangle size={16} />,
        className: 'bg-dark-700 cursor-not-allowed',
      };
    }
    
    if (!mintConfig.contractAddress) {
      return {
        disabled: true,
        text: 'Enter Contract Address',
        icon: <AlertTriangle size={16} />,
        className: 'bg-dark-700 cursor-not-allowed',
      };
    }
    
    if (mintConfig.startTime && currentTime < mintConfig.startTime) {
      return {
        disabled: true,
        text: 'Mint Not Live Yet',
        icon: <AlertTriangle size={16} />,
        className: 'bg-dark-700 cursor-not-allowed',
      };
    }
    
    if (isMinting) {
      return {
        disabled: true,
        text: 'Minting...',
        icon: <Loader2 className="animate-spin" size={16} />,
        className: 'bg-primary-600 cursor-wait',
      };
    }
    
    return {
      disabled: false,
      text: `Mint NFT (${mintConfig.mintQuantity})`,
      icon: null,
      className: 'bg-primary-600 hover:bg-primary-700',
    };
  };
  
  const buttonState = getButtonState();
  
  return (
    <div className="mt-4">
      <button
        onClick={handleMint}
        disabled={buttonState.disabled}
        className={`w-full py-3 px-4 rounded-lg text-white font-semibold transition-colors flex items-center justify-center gap-2 ${buttonState.className}`}
      >
        {buttonState.icon}
        {buttonState.text}
      </button>
      
      {isReadyToMint && (
        <div className="mt-2 text-center text-xs text-gray-400">
          Total Cost: ~{(
            parseFloat(mintConfig.mintPrice) * mintConfig.mintQuantity +
            (parseFloat(gasSettings.maxFeePerGas) * parseFloat(gasSettings.gasLimit)) / 1e9
          ).toFixed(6)}{' '}
          ETH
        </div>
      )}
    </div>
  );
};

export default MintButton;