import React, { useEffect } from 'react';
import { FileText, Clock, Hash } from 'lucide-react';
import { useMintStore } from '../store/mintStore';
import { useWalletStore } from '../store/walletStore';
import { getServerTime } from '../utils/web3';

const MintConfigForm: React.FC = () => {
  const { mintConfig, updateMintConfig, estimateGasLimit } = useMintStore();
  const { wallet } = useWalletStore();
  
  useEffect(() => {
    if (wallet?.provider && mintConfig.contractAddress) {
      estimateGasLimit(wallet.provider, mintConfig.contractAddress);
    }
  }, [mintConfig.contractAddress, wallet?.provider, estimateGasLimit]);
  
  const handleSyncTime = async () => {
    const serverTime = await getServerTime();
    updateMintConfig({ startTime: serverTime });
  };
  
  return (
    <div className="bg-dark-800 rounded-lg p-4 border border-dark-700">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold text-white flex items-center gap-2">
          <FileText size={18} className="text-primary-400" />
          Contract Configuration
        </h2>
      </div>
      
      <div className="space-y-4">
        <div>
          <label className="text-sm font-medium text-gray-300 mb-1">Contract Address</label>
          <input
            type="text"
            value={mintConfig.contractAddress}
            onChange={(e) => updateMintConfig({ contractAddress: e.target.value })}
            placeholder="0x..."
            className="w-full bg-dark-900 border border-dark-700 text-white rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-primary-500"
          />
        </div>
        
        <div>
          <label className="text-sm font-medium text-gray-300 mb-1">Mint Function</label>
          <input
            type="text"
            value={mintConfig.mintFunction}
            onChange={(e) => updateMintConfig({ mintFunction: e.target.value })}
            placeholder="mint(uint256)"
            className="w-full bg-dark-900 border border-dark-700 text-white rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-primary-500"
          />
          <p className="text-xs text-gray-400 mt-1">
            Function signature (e.g., mint(uint256) or mintWhitelist(uint256,bytes32[]))
          </p>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="text-sm font-medium text-gray-300 mb-1">Mint Price (ETH)</label>
            <input
              type="number"
              value={mintConfig.mintPrice}
              onChange={(e) => updateMintConfig({ mintPrice: e.target.value })}
              step="0.001"
              min="0"
              className="w-full bg-dark-900 border border-dark-700 text-white rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-primary-500"
            />
          </div>
          
          <div>
            <label className="text-sm font-medium text-gray-300 mb-1">Quantity</label>
            <input
              type="number"
              value={mintConfig.mintQuantity}
              onChange={(e) => updateMintConfig({ 
                mintQuantity: parseInt(e.target.value, 10),
                arguments: [parseInt(e.target.value, 10)]
              })}
              min="1"
              max="20"
              className="w-full bg-dark-900 border border-dark-700 text-white rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-primary-500"
            />
          </div>
        </div>
        
        <div className="flex flex-col">
          <label className="text-sm font-medium text-gray-300 mb-1 flex items-center gap-2">
            <Clock size={16} className="text-gray-400" />
            Mint Start Time (UTC)
          </label>
          <div className="flex gap-2">
            <input
              type="datetime-local"
              value={
                mintConfig.startTime
                  ? new Date(mintConfig.startTime * 1000).toISOString().slice(0, 16)
                  : ''
              }
              onChange={(e) => {
                const date = new Date(e.target.value);
                updateMintConfig({ startTime: Math.floor(date.getTime() / 1000) });
              }}
              className="flex-1 bg-dark-900 border border-dark-700 text-white rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-primary-500"
            />
            <button
              onClick={handleSyncTime}
              className="bg-primary-600 hover:bg-primary-700 text-white px-3 rounded transition-colors flex items-center gap-1"
            >
              <Hash size={16} />
              Now
            </button>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <input
            type="checkbox"
            id="whitelist"
            checked={mintConfig.whitelistRequired}
            onChange={(e) => updateMintConfig({ whitelistRequired: e.target.checked })}
            className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-600 rounded"
          />
          <label htmlFor="whitelist" className="text-sm font-medium text-gray-300">
            Whitelist Required
          </label>
        </div>
        
        {mintConfig.whitelistRequired && (
          <div>
            <label className="text-sm font-medium text-gray-300 mb-1">Merkle Proof</label>
            <textarea
              value={mintConfig.merkleProof?.join('\n') || ''}
              onChange={(e) =>
                updateMintConfig({ merkleProof: e.target.value.split('\n').filter(Boolean) })
              }
              placeholder="Enter merkle proof (one hash per line)"
              className="w-full bg-dark-900 border border-dark-700 text-white rounded-md p-2 h-24 focus:outline-none focus:ring-2 focus:ring-primary-500"
            />
          </div>
        )}
      </div>
    </div>
  );
};

export default MintConfigForm;