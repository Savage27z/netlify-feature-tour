import React from 'react';
import { useWalletStore } from '../store/walletStore';
import { NETWORKS } from '../constants/networks';
import { NetworkConfig } from '../types';

const NetworkSelector: React.FC = () => {
  const { wallet, switchNetwork } = useWalletStore();
  const networks = Object.values(NETWORKS);
  
  const handleNetworkChange = (chainId: number) => {
    switchNetwork(chainId);
  };
  
  return (
    <div className="w-full max-w-xs">
      <label htmlFor="network" className="block text-sm font-medium text-gray-200 mb-1">
        Network
      </label>
      <div className="relative">
        <select
          id="network"
          className="block w-full bg-dark-800 border border-dark-600 text-white rounded-lg p-2.5 appearance-none focus:outline-none focus:ring-2 focus:ring-primary-500"
          value={wallet?.network?.chainId || 1}
          onChange={(e) => handleNetworkChange(parseInt(e.target.value, 10))}
          disabled={!wallet}
        >
          {networks.map((network) => (
            <option key={network.chainId} value={network.chainId}>
              {network.name}
            </option>
          ))}
        </select>
        <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-white">
          <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
            <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z" />
          </svg>
        </div>
      </div>
    </div>
  );
};

export default NetworkSelector;